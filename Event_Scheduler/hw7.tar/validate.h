#ifndef VALIDATE_H_INCLUDED

#include <stdio.h>
#include <unistd.h>

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>

tm date_parser(std::string indate);

#define VALIDATE_H_INCLUDED
#endif /* VALIDATE_H_INCLUDED */